<?php

use Illuminate\Support\Facades\Route;

use Modules\AddOnManager\Http\Controllers\AddOnController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your aaplication. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




// Route::get('/', function () {
//     return view('auth/login');
// });

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth'])->name('dashboard');


Route::group(['middleware' => 'auth'], function () {

    Route::post('changeStatus', [AddOnController::class, 'changeStatus'])->name('changeStatus');
    Route::resource('add-on-manager', AddOnController::class);

});

