<x-app-layout>

    <div class="container-fluid">
        <div class="layout-specing">

            <div class="row ">
                <div class="col-md-12 col-lg-12 my-0 lead_list">
                    <div class="card rounded shadow pb-1">
                        <div class=" border-0 quotation_form">
                            <div
                                class="card-header py-3 bg-transparent d-flex align-items-center justify-content-between">
                                <h5 class="tx-uppercase tx-semibold mb-0">Category List</h5>
                              
                            </div>
                        </div>
                        <!-- searchbar -->
                        <div class="row" id="search">
                            <div class="col-sm-1">
                                <select class="form-select form-control ">
                                    <option>1</option>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <input type="text" id="searchbar" class="form-control" placeholder="Search Here"
                                    aria-label="Search" />
                            </div>
                        </div>
                        <!-- end searchbar -->
                        <div class="p-4 mt-1">
                            <div class="table-responsive shadow rounded " id="customer_table">
                                <!-- Start table -->
                                <table class="table table-center bg-white mb-0">
                                    <thead>
                                        <tr>
                                                <th class="border-bottom col-sm-1">
                                                    {{__('common.sl_no')}}</th>
                                                <th class="border-bottom col-sm-1">
                                                    Category Name</th>
                                                <th class="border-bottom col-sm-1">
                                                    Sort Order</th>
                                                <th class="border-bottom text-center col-sm-1">
                                                    {{__('common.status')}}</th>
                                                <th class="border-bottom text-center col-sm-1">
                                                    {{__('common.action')}}</th>
                                                </tr>
                                        </tr>
                                    </thead>
                                    <tbody id="table">

                                        @if(!empty($PCCategory_list))
                                            @foreach($PCCategory_list as $key=>$category)
                                                <tr>
                                                    <td class="text-left ">{{$key+1}}</td>
                                                    <td class="text-left "> 
                                                        @if (!empty($category->categorydescription))
                                                        {{ $category->categorydescription[0]->categories_name }}
                                                        @endif
                                                    </td>
                                                    <td class="text-left  ">
                                                        <input type="number" class="col-xs-1 inputPassword2 width1" data-categories_id="{{$category->categories_id}}"  placeholder="" value="{{$category->sort_order}}" style="width:50px;">
                                                    </td>
                                                    <td class="text-center"> 
                                                        <div class="form-check form-switch">
                                                        <input data-categories_id="{{$category->categories_id}}"
                                                        class="form-check-input toggle-class" type="checkbox"
                                                        data-toggle="toggle" data-on="active" data-off="InActive" {{ $category->isavailabel=="Yes" ? 'checked' : '' }}>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">
                                                        <button class="btn btn-primary" >
                                                       <a href="{{ route('pc-categories.show', $category->categories_id) }}">@</a>
                                                            <!-- <a href="{{url('pc-categories',$category->categories_id) }}">
                                                                @
                                                            </a> -->
                                                        </button>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table><!-- end table -->
                            </div>
                            <div class="row text-center px-2">
                                <!-- PAGINATION START -->
                                <div class="col-12 mt-4">
                                    <div class="d-md-flex align-items-center text-center justify-content-between">
                                        <span class="text-muted me-3">Showing {{$PCCategory_list->currentPage();}} - {{$PCCategory_list->lastItem();}} out of {{$PCCategory_list->total()}}</span>
                                        <ul class="pagination mb-0 justify-content-center mt-4 mt-sm-0">
                                            {{ $PCCategory_list->links() }}
                                        </ul>
                                    </div>
                                </div>
                                    <!-- PAGINATION END -->
                            </div><!--end row-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!--start delete modal-->
<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Customer</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
        </div>
        <div class="modal-body">
            <h5>Are you sure want to delete ?</h5>
            <input type="hidden" id="delete_department_id" name="input_field_id">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">NO</button>
            <button type="submit" class="btn btn-primary delete_submit_btn">Yes</button>
        </div>
    </div>
</div>
</div>
<!--end delete modal-->

@push('scripts')

    
<script type="text/javascript">
  
  $('.toggle-class').change(function () {
      let status = $(this).prop('checked') === true ? 1 : 0;
      let categories_id = $(this).data('categories_id');
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
          type: "POST",
          dataType: "json",
          url: "{{ url('changeStatus') }}",
          data: { 'status': status, 'categories_id': categories_id },
          success: function (response) {
             Toaster(response.success);
          }
      });
  });
</script>

<script>
        $(document).ready(function() {

         // category sort order update
            $(".inputPassword2").on("blur",function(e){ 
                e.preventDefault();
                var categories_id = $(this).data('categories_id');
                var sort_order = $(this).val();
                console.log(categories_id);
                console.log(sort_order);
                $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                $.ajax({
                    type:"POST",
                    url: "{{route('pcCategrySortOrder')}}",
                    data:{categories_id:categories_id,sort_order:sort_order},
                    dataType:"json",
                    success:function(data){
                        Toaster(data.success);
                    }
                }); 
            }); 
        });
        
    </script>

@endpush
</x-app-layout>