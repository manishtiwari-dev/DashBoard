<?php

namespace Modules\Pcapi\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Auth;
use Modules\Pcapi\Models\PcCategoryDescription;
use Modules\Pcapi\Models\PcCategory;
use Illuminate\Support\Str;
use App\Models\Category;



class PcCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public static function index(Request $request){
        

        $catId = $request->categories_id;
        

        $PCCategory_list = PcCategory::with('categorydescription')->where('parent_id', $request->has('catId') ? $catId : 0)->orderBy('sort_order', 'DESC')->paginate(50);

        foreach($PCCategory_list as $PcCateData)
        {
            $EcomCategory=Category::where('source',2)->where('status',1)->where('source_id',$PcCateData->categories_id)->first();
            if(!empty($EcomCategory))
            $PcCateData['isavailabel']="Yes";
            else
            $PcCateData['isavailabel']="No";
        }
        return view('Pcapi::category.index',compact('PCCategory_list'));

     }



    public function changeStatus(Request $request)
    {
        $pcCategory =  PcCategory::where('categories_id' ,$request->categories_id)->first(); 
        if(!empty($pcCategory))
        {   
            $ecmCate=PcCategory::CategoryAddStatusUpdate($request,$pcCategory);
            
            //  Add Products

            PcCategory::ProductAddStatusUpdate($request, $pcCategory->categories_id, $ecmCate);

            $pcChildCategory =PcCategory::cateChildAry($pcCategory->categories_id);
            // dd($pcChildCategory);
            if(!empty($pcChildCategory)){
                foreach($pcChildCategory as $childCateId){
                    $pcCategory1 =  PcCategory::where('categories_id' ,$childCateId)->first();
                    $ecmCate1=PcCategory::CategoryAddStatusUpdate($request,$pcCategory1, $ecmCate->categories_id);
                    PcCategory::ProductAddStatusUpdate($request,$childCateId, $ecmCate1);
                }
            }
         }

        return response()->json(['status'=>1, 'success'=>' Category  Status Changed Successfully']);
    }

         /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ChangeShortOrder(Request $request)
    {
            
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         
        $catId = $id;
        

        $PCCategory_list = PcCategory::with('categorydescription')->where('parent_id',  $catId )->orderBy('sort_order', 'DESC')->paginate(50);

        
        foreach($PCCategory_list as $PcCateData)
        {
            $EcomCategory=Category::where('source',2)->where('status',1)->where('source_id',$PcCateData->categories_id)->first();
            if(!empty($EcomCategory))
            $PcCateData['isavailabel']="Yes";
            else
            $PcCateData['isavailabel']="No";
        }
        return view('Pcapi::category.index',compact('PCCategory_list'));




      //  dd($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      
      //

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function catProduct(Request $request)
    {
        // dd($request->categories_id);

    }


    public function sortOrder(Request $request)
    {
        $pcCategory = PcCategory::where('categories_id' ,$request->categories_id )->first();
        if(!empty($pcCategory))
        {
            $category =  Category::where('source_id',$pcCategory->categories_id)->where('source', 2)->first();
            if(!empty($category))
            {
                $category->sort_order = $request->sort_order;
                $category->update();
                return response()->json(['status'=>1, 'success'=>' Category Sort Order Changed Successfully']);
            }
            else 
            {
                return response()->json(['status'=>1, 'success'=>'Please enable Category status first then change Category sort order']); 
            }  
         }

    }

}
