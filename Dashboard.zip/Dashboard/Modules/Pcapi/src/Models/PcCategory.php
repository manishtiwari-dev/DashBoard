<?php

namespace Modules\Pcapi\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Pcapi\Models\PcCategoryDescription;

class PcCategory extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $connection='mysqlSuper';
    protected $table = "ecm_pc_categories";
    protected $primaryKey = 'categories_id';
    protected $guarded = [
           'categories_id',
    ];

    public function categorydescription(){
        return $this->hasMany(PcCategoryDescription::class, 'categories_id', 'categories_id');
    }
  

}
