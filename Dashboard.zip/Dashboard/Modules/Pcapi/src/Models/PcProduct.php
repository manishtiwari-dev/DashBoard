<?php

namespace Modules\Pcapi\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Pcapi\Models\PcProductDescription;

class PcProduct extends Model
{
    use HasFactory;


    protected $connection='mysqlSuper';
    protected $table = "ecm_pc_products";
    protected $primaryKey = 'product_id';
    protected $guarded = [
           'product_id',
    ];

  
    public function productdescription(){
        return $this->hasMany(PcProductDescription::class, 'products_id', 'products_id');
    }
  

}
